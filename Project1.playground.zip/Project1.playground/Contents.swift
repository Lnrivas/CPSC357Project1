import UIKit
//: # Project #1

//: ## Problem 1:
/*:
 Function that takes an integer as parameter and returns a boolean representing if it is a prime number or not. Return true if parameter number is 2 to account for that special case, else loop through the numbers 2 to parameter-1 and check if divisible using modulus (avoids division by 0,1, and number). if number % index == 0, then not prime, return false. else, return true.
 */

func isPrime(_ number: Int) -> Bool {
    if (number == 2) { //accounts for if number is 2, which is prime
        return true
    } else {
        for index in 2...number-1 { //avoids dividing by 0,1, or number because these can be true and it still be prime
            if (number % index == 0) {
                return false
            }
        }
        return true
    }
}
//: Example test cases:
isPrime(2) // true
isPrime(3) // true
isPrime(10) // false
isPrime(13) // true
//: ## Problem 2:
/*:
 Function that takes an int for the first hour, and int for the first minutes, an int for the second hour, and an int for the second minute as parameters and returns a string telling the difference in time. All ints defined are constants here because they are never mutated. First initialize an int to keep track of the first input time in just minutes, by multiplying the firstHour by 60 and adding the firstMinute. Then initialize an int to keep track of the second input time by multiplying the secondHour by 60 and adding the secondMinute. Then initialize the finalTimeInMinutes by taking the difference between the first 2 initialized ints. then divide by 60 to get the outputHour and get the modulus by 60 to find the outputMinute. if outPutMinute is a single digit, add a 0 in front of it in the output string to make sure the right digit represents the minutes. Then output the wait time as a string.
 */

func waitingTime(firstHour: Int, firstMinute: Int, secondHour: Int, secondMinute: Int) -> String {
    let firstTimeInMinutes: Int = (firstHour * 60) + firstMinute
    let secondTimeInMinutes: Int = (secondHour * 60) + secondMinute
    let finalTimeInMinutes: Int = secondTimeInMinutes - firstTimeInMinutes
    let outputHour: Int = finalTimeInMinutes / 60
    let outputMinute: Int = finalTimeInMinutes % 60
    if (outputMinute < 10) { //account for 0-9 minutes being in the correct digit place, aka saying 1:05 not 1:5
        return "You should wait \(outputHour):0\(outputMinute) "
    } else {
        return "You should wait \(outputHour):\(outputMinute) "
    }
}
//: Example test cases:
waitingTime(firstHour: 11, firstMinute: 30, secondHour: 13, secondMinute: 15) //Output should be: “You should wait 1:45"
waitingTime(firstHour: 10, firstMinute: 30, secondHour: 13, secondMinute: 15) //Output should be: “You should wait 2:45"
waitingTime(firstHour: 12, firstMinute: 30, secondHour: 13, secondMinute: 15) //Output should be: “You should wait 0:45"
waitingTime(firstHour: 11, firstMinute: 10, secondHour: 13, secondMinute: 15) //Output should be: “You should wait 2:05"
waitingTime(firstHour: 11, firstMinute: 30, secondHour: 13, secondMinute: 55) //Output should be: “You should wait 2:25"
waitingTime(firstHour: 11, firstMinute: 30, secondHour: 13, secondMinute: 30) //Output should be: “You should wait 2:00"
//: ## Problem 4:
/*:
 Function that takes a String parameter and returns a string stating wether the input was a valid email or not. First it sets the input string into a constant array to make it easier to iterate through. A variable Name is created to store the name (whatever is before the @ in the email) in the event that the email is valid. Then it loops through the enough of the email to leave space for a @ and . text between everything. If it finds a @, it sets everything before hand to the name and loops until it finds a . with text after it. If all that happens, it returns the name, else it is not a valid email. 
 */

func validateEmail(email: String) -> String {
    let emailArray = Array(email)
    var name: String
    for index1 in 1...emailArray.count-3 { //check for @
        if (emailArray[index1] == "@") {
            name = String(emailArray[0..<index1])
            for index2 in index1+1...emailArray.count-2 { // check for .
                if (emailArray[index2] == ".") {
                    return "Thanks for the email \(name)" //everything before @
                }
            }
        }
    }
    return "Provide a valid email"
}
//: Example test cases:
validateEmail(email: "cibrian@chapman.edu") // “Thanks for the email Cibrian”
validateEmail(email: "hipjasif@gmail.com") // “Thanks for the email hipjasif”
validateEmail(email: "thisisnot an email") // “Provide a valid email”
validateEmail(email: "cibrien.edu") // “Provide a valid email”
